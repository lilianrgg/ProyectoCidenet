package com.prueba.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="TBL_EMPLEADOS")
public class EmpleadosEntity {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    public Long getId() {
		return id;
	}

    @Size(max=20)
    @Pattern(regexp="[/^[a-z]]")
	@Column(name="Primer_Apellido")
    private String PrimerApellido;

    @Size(max=20)
    @Pattern(regexp="[/^[a-z]]")
    @Column(name="Segundo_Apellido")
    private String SegundoApellido;
    
    @Size(max=20)
    @Pattern(regexp="[/^[a-z]]")
    @Column(name="Primer_Nombre")
    private String PrimerNombre;

    @Size(max=50)
    @Pattern(regexp="[/^[a-z]]")
    @Column(name="Otros_Nombres")
    private String OtrosNombres;    

    @Column(name="Pais_Empleo")
    private String PaisEmpleo;    

    @Column(name="Tipo_Identificacion")
    private String TipoIdentificacion;    
    
    @Size(max=20)
    @Pattern(regexp="[[a-z/A-Z/0-9/-]]")
    @Column(name="Numero_Identificacion")
    private String NumeroIdentificacion;    
    
    @Size(max=300)
    @Column(name="Email")
    private String Email;
    
    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name="Fecha_Ingreso")
    private Date FechaIngreso;  
    
    @Column(name="Area")
    private String Area;   
    
    @Column(name="Estado")
    private String Estado;   
    
    @Column(name="Fecha_Registro")
    @DateTimeFormat(pattern="dd/MM/yyyy")
    private Date FechaRegistro;  
    
    public void setId(Long id) {
		this.id = id;
	}

	public String getPrimerApellido() {
		return PrimerApellido;
	}

	public void setPrimerApellido(String primerApellido) {
		PrimerApellido = primerApellido;
	}

	public String getSegundoApellido() {
		return SegundoApellido;
	}

	public void setSegundoApellido(String segundoApellido) {
		SegundoApellido = segundoApellido;
	}

	public String getPrimerNombre() {
		return PrimerNombre;
	}

	public void setPrimerNombre(String primerNombre) {
		PrimerNombre = primerNombre;
	}

	public String getOtrosNombres() {
		return OtrosNombres;
	}

	public void setOtrosNombres(String otrosNombres) {
		OtrosNombres = otrosNombres;
	}

	public String getPaisEmpleo() {
		return PaisEmpleo;
	}

	public void setPaisEmpleo(String paisEmpleo) {
		PaisEmpleo = paisEmpleo;
	}

	public String getTipoIdentificacion() {
		return TipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		TipoIdentificacion = tipoIdentificacion;
	}

	public String getNumeroIdentificacion() {
		return NumeroIdentificacion;
	}

	public void setNumeroIdentificacion(String numeroIdentificacion) {
		NumeroIdentificacion = numeroIdentificacion;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public Date getFechaIngreso() {
		return FechaIngreso;
	}

	public void setFechaIngreso(Date fechaIngreso) {
		FechaIngreso = fechaIngreso;
	}

	public String getArea() {
		return Area;
	}

	public void setArea(String area) {
		Area = area;
	}

	public String getEstado() {
		return Estado;
	}

	public void setEstado(String estado) {
		Estado = estado;
	}

	public Date getFechaRegistro() {
		return FechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		FechaRegistro = fechaRegistro;
	}
   
}