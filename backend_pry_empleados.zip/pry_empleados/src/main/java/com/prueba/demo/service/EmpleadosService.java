package com.prueba.demo.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prueba.demo.exception.RecordNotFoundException;
import com.prueba.demo.model.EmpleadosEntity;
import com.prueba.demo.repository.EmpleadosRepository;
 
@Service
public class EmpleadosService {
     
    @Autowired
    EmpleadosRepository repository;
     
    public List<EmpleadosEntity> getAllEmpleados()
    {
        List<EmpleadosEntity> EmpleadoList = repository.findAll();
         
        if(EmpleadoList.size() > 0) {
            return EmpleadoList;
        } else {
            return new ArrayList<EmpleadosEntity>();
        }
    }
     
    public EmpleadosEntity getEmpleadoById(Long id) throws RecordNotFoundException
    {
        Optional<EmpleadosEntity> Empleado = repository.findById(id);
         
        if(Empleado.isPresent()) {
            return Empleado.get();
        } else {
            throw new RecordNotFoundException("No existe ningún registro de empleado para la identificación dada");
        }
    }
     
    public EmpleadosEntity createOrUpdateEmpleado(EmpleadosEntity entity) throws RecordNotFoundException, ParseException
    {
        Optional<EmpleadosEntity> Empleado = repository.findById(entity.getId());
         
        if(Empleado.isPresent())
        {
        	
        	SimpleDateFormat formatearFecIng = new SimpleDateFormat("dd/MM/yyyy");
        	SimpleDateFormat formatearFecReg = new SimpleDateFormat("dd/MM/yyyy");
        	
            EmpleadosEntity newEntity = Empleado.get();
            
            newEntity.setPrimerNombre(entity.getPrimerNombre());
            newEntity.setOtrosNombres(entity.getOtrosNombres());
            newEntity.setPrimerApellido(entity.getPrimerApellido());
            newEntity.setSegundoApellido(entity.getSegundoApellido());
            newEntity.setEmail(entity.getEmail());
            newEntity.setArea(entity.getArea());
            newEntity.setEstado(entity.getEstado());
            newEntity.setTipoIdentificacion(entity.getTipoIdentificacion());
            newEntity.setNumeroIdentificacion(entity.getNumeroIdentificacion());
            newEntity.setFechaIngreso(formatearFecIng.parse(entity.getFechaIngreso().toString()));
            newEntity.setFechaRegistro(formatearFecReg.parse(entity.getFechaRegistro().toString()));
            newEntity.setPaisEmpleo(entity.getPaisEmpleo());
            
            newEntity = repository.save(newEntity);
             
            return newEntity;
        } else {
            entity = repository.save(entity);
             
            return entity;
        }
    }
     
    public void deleteEmpleadoById(Long id) throws RecordNotFoundException
    {
        Optional<EmpleadosEntity> Empleado = repository.findById(id);
         
        if(Empleado.isPresent())
        {
            repository.deleteById(id);
        } else {
            throw new RecordNotFoundException("No existe ningún registro de empleado para la identificación dada");
        }
    }
}