INSERT INTO 
	TBL_EMPLEADOS (Primer_Apellido, Segundo_Apellido, Primer_Nombre,Otros_Nombres,Pais_Empleo,Tipo_Identificacion,
	  Numero_Identificacion,Email,Fecha_Ingreso,Area,Estado,Fecha_Registro) 
VALUES
  	('Gutierrez', 'Rojas', 'Gustavo','','Colombia','CC','29372622','GustGutRoj@gmail.com', '2010-02-15','Area Ppal','A', '2010-02-10'),
  	('Gonzalez', 'Rodriguez', 'Pablo','','Colombia','CC','34566','PabloGonzaRod@gmail.com', '2010-01-01','Area Ppal','A', '2010-01-01'),
	('Gutierrez', 'Fernandez', 'Maria','Patricia','Colombia','CC','593833322','MariaPatGut@gmail.com', '2011-01-01','Area UNO','A', '2011-01-01');	